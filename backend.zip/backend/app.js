const s = "https://www.smartprix.com/mobiles/motorola-moto-g85-5g-ppd1atwftc6s"

const f = s.split('/').slice(-2).join("/");
console.log(f)

